package com.example.helloworld

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val days = mapOf(1 to "Sunday", 2 to "Monday", 3 to "Tuesday", 4 to "Wednesday",
            5 to "Thursday", 6 to "Friday", 7 to "Saturday")

        for(i in days){
            println("${i.key}: ${i.value}")
            Log.d("MainActivity","${i.key}: ${i.value}")
        }
    }
}